# Trading Dashboard (ASX + BTC)

## Instructions
1. Create a GitHub repo and upload:
   - dashboard.py
   - requirements.txt
   - README.md
2. Deploy via https://streamlit.io/cloud
3. Use `dashboard.py` as entry point
